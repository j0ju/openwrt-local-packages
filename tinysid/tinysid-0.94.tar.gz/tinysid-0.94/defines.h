#ifndef SYS_TYPES
#define SYS_TYPES
typedef unsigned char  byte;
typedef unsigned short word;
typedef unsigned long  dword;
#endif
